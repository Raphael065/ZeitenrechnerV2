﻿using System;
using System.Threading.Tasks;
using FirebaseDiscordChat.Services;
using FirebaseDiscordChat.UI;
using FirebaseDiscordChat.Utils;

namespace FirebaseDiscordChat
{
    class Program
    {
        static async Task Main(string[] args)
        {
            try
            {
                // Initialize services
                var firebaseService = new FirebaseService();
                var userService = new UserService(firebaseService);
                var channelService = new ChannelService(firebaseService, userService);
                var messageService = new MessageService(firebaseService, userService);

                // Updated to also pass firebaseService to CommandHandler
                var commandHandler = new CommandHandler(channelService, userService, messageService, firebaseService);

                // Initialize UI
                var consoleUI = new ConsoleUI(channelService, userService, messageService, commandHandler);
                consoleUI.Initialize();

                // Show login form
                string username = consoleUI.ShowLoginForm();

                if (string.IsNullOrWhiteSpace(username))
                {
                    Console.WriteLine("Username cannot be empty. Press any key to exit.");
                    Console.ReadKey();
                    return;
                }

                // Initialize default channels if they don't exist
                await channelService.InitializeDefaultChannels();

                // Initialize user
                await userService.Initialize(username);

                // Start a background task to periodically poll for messages
                _ = Task.Run(async () =>
                {
                    while (true)
                    {
                        await messageService.PollNewMessages();
                        await Task.Delay(Config.MessagePollingInterval);
                    }
                });

                // Start a background task to periodically poll for active users
                _ = Task.Run(async () =>
                {
                    while (true)
                    {
                        await userService.GetActiveUsers();
                        await Task.Delay(Config.UserPollingInterval);
                    }
                });

                // Start the UI loop
                await consoleUI.StartUILoop();
            }
            catch (Exception ex)
            {
                Console.Clear();
                Console.ForegroundColor = ConsoleColor.Red;
                Console.WriteLine($"Fatal error: {ex.Message}");
                Console.WriteLine(ex.StackTrace);
                Console.ResetColor();
                Console.WriteLine("\nPress any key to exit...");
                Console.ReadKey();
            }
        }
    }
}