﻿using System;
using System.Collections.Generic;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using FirebaseDiscordChat.Utils;
using FirebaseDiscordChat.Models;

namespace FirebaseDiscordChat.Services
{
    public class FirebaseService
    {
        private static readonly HttpClient httpClient = new HttpClient();
        private readonly string baseUrl;

        public FirebaseService()
        {
            baseUrl = Config.FirebaseUrl;

            // Configure HttpClient
            httpClient.Timeout = TimeSpan.FromSeconds(10);
            httpClient.DefaultRequestHeaders.Add("Accept", "application/json");
        }

        /// <summary>
        /// Retrieves data from Firebase with better error handling
        /// </summary>
        public async Task<T> GetAsync<T>(string path)
        {
            try
            {
                var response = await httpClient.GetAsync($"{baseUrl}{path}.json");
                response.EnsureSuccessStatusCode();

                var content = await response.Content.ReadAsStringAsync();

                if (string.IsNullOrWhiteSpace(content) || content == "null")
                {
                    return default;
                }

                // If retrieving users, handle special case
                if (path == Config.UsersPath && typeof(T) == typeof(Dictionary<string, User>))
                {
                    try
                    {
                        // First try normal deserialization
                        return JsonConvert.DeserializeObject<T>(content);
                    }
                    catch (JsonSerializationException ex)
                    {
                        // If that fails, try manual parsing
                        return (T)(object)ParseUsersManually(content);
                    }
                }

                return JsonConvert.DeserializeObject<T>(content);
            }
            catch (JsonSerializationException ex)
            {
                LogError($"Firebase GET error ({path}): {ex.Message}");

                // Try to create an empty result for collections
                if (typeof(T).IsGenericType && typeof(T).GetGenericTypeDefinition() == typeof(Dictionary<,>))
                {
                    return (T)Activator.CreateInstance(typeof(T));
                }

                throw;
            }
            catch (Exception ex)
            {
                LogError($"Firebase GET error ({path}): {ex.Message}");
                throw;
            }
        }

        /// <summary>
        /// Creates or updates data at the specified path
        /// </summary>
        public async Task PutAsync<T>(string path, T data)
        {
            try
            {
                var json = JsonConvert.SerializeObject(data);
                var content = new StringContent(json, Encoding.UTF8, "application/json");

                var response = await httpClient.PutAsync($"{baseUrl}{path}.json", content);
                response.EnsureSuccessStatusCode();
            }
            catch (Exception ex)
            {
                LogError($"Firebase PUT error ({path}): {ex.Message}");
                throw;
            }
        }

        /// <summary>
        /// Updates only specified fields at the given path (using PATCH method)
        /// </summary>
        public async Task PatchAsync<T>(string path, T data)
        {
            try
            {
                var json = JsonConvert.SerializeObject(data);
                var content = new StringContent(json, Encoding.UTF8, "application/json");

                // Use PUT method as a fallback since PATCH might not be supported
                var method = new HttpMethod("PATCH");
                var request = new HttpRequestMessage(method, $"{baseUrl}{path}.json")
                {
                    Content = content
                };

                var response = await httpClient.SendAsync(request);
                response.EnsureSuccessStatusCode();
            }
            catch (Exception ex)
            {
                LogError($"Firebase PATCH error ({path}): {ex.Message}");
                throw;
            }
        }

        /// <summary>
        /// Creates a new object with a Firebase-generated ID
        /// </summary>
        public async Task<string> PostAsync<T>(string path, T data)
        {
            try
            {
                var json = JsonConvert.SerializeObject(data);
                var content = new StringContent(json, Encoding.UTF8, "application/json");

                var response = await httpClient.PostAsync($"{baseUrl}{path}.json", content);
                response.EnsureSuccessStatusCode();

                var result = await response.Content.ReadAsStringAsync();
                var responseObj = JsonConvert.DeserializeObject<Dictionary<string, string>>(result);

                // Return the generated Firebase ID (name)
                return responseObj["name"];
            }
            catch (Exception ex)
            {
                LogError($"Firebase POST error ({path}): {ex.Message}");
                throw;
            }
        }

        /// <summary>
        /// Deletes data at the specified path
        /// </summary>
        public async Task DeleteAsync(string path)
        {
            try
            {
                var response = await httpClient.DeleteAsync($"{baseUrl}{path}.json");
                response.EnsureSuccessStatusCode();
            }
            catch (Exception ex)
            {
                LogError($"Firebase DELETE error ({path}): {ex.Message}");
                throw;
            }
        }

        /// <summary>
        /// Manually parse users from JSON when normal deserialization fails
        /// </summary>
        private Dictionary<string, User> ParseUsersManually(string content)
        {
            var result = new Dictionary<string, User>();

            try
            {
                // Parse the JSON to a JObject first
                var jsonObj = JObject.Parse(content);

                foreach (var property in jsonObj.Properties())
                {
                    try
                    {
                        string username = property.Name;
                        JToken tokenValue = property.Value;

                        // Skip if the value is not an object
                        if (tokenValue.Type != JTokenType.Object)
                        {
                            LogError($"Skipping invalid user data format for {username}: Value is not an object");
                            continue;
                        }

                        // Create a new user
                        var user = new User
                        {
                            Username = username
                        };

                        // Parse each property safely
                        foreach (JProperty userProp in tokenValue.Children<JProperty>())
                        {
                            string propName = userProp.Name;
                            JToken propValue = userProp.Value;

                            switch (propName)
                            {
                                case "displayName":
                                    if (propValue.Type == JTokenType.String)
                                        user.DisplayName = propValue.ToString();
                                    break;

                                case "status":
                                    if (propValue.Type == JTokenType.String)
                                        user.Status = propValue.ToString();
                                    break;

                                case "customStatus":
                                    if (propValue.Type == JTokenType.String)
                                        user.CustomStatus = propValue.ToString();
                                    break;

                                case "avatarColor":
                                    if (propValue.Type == JTokenType.String)
                                        user.AvatarColor = propValue.ToString();
                                    break;

                                case "currentChannel":
                                    if (propValue.Type == JTokenType.String)
                                        user.CurrentChannel = propValue.ToString();
                                    break;

                                case "lastActive":
                                    if (propValue.Type == JTokenType.Integer)
                                        user.LastActive = (long)propValue;
                                    else if (propValue.Type == JTokenType.Float)
                                        user.LastActive = (long)(double)propValue;
                                    else if (propValue.Type == JTokenType.String && long.TryParse(propValue.ToString(), out long timestamp))
                                        user.LastActive = timestamp;
                                    break;

                                case "joinedAt":
                                    if (propValue.Type == JTokenType.Integer)
                                        user.JoinedAt = (long)propValue;
                                    else if (propValue.Type == JTokenType.Float)
                                        user.JoinedAt = (long)(double)propValue;
                                    else if (propValue.Type == JTokenType.String && long.TryParse(propValue.ToString(), out long timestamp))
                                        user.JoinedAt = timestamp;
                                    break;
                            }
                        }

                        result.Add(username, user);
                    }
                    catch (Exception ex)
                    {
                        // Just skip this user if we can't parse it
                        LogError($"Could not parse user {property.Name}: {ex.Message}");
                    }
                }
            }
            catch (Exception ex)
            {
                LogError($"Manual user parsing error: {ex.Message}");
                // Return empty dictionary if parsing fails
            }

            return result;
        }

        private void LogError(string message)
        {
            Console.ForegroundColor = ConsoleColor.Red;
            Console.WriteLine($"[ERROR] {message}");
            Console.ResetColor();
        }
    }
}