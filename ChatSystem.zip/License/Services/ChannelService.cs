﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using FirebaseDiscordChat.Models;
using FirebaseDiscordChat.Utils;

namespace FirebaseDiscordChat.Services
{
    public class ChannelService
    {
        private readonly FirebaseService _firebaseService;
        private readonly UserService _userService;
        private List<Channel> _cachedChannels = new List<Channel>();
        private string _currentChannelId = "general";

        public event EventHandler<List<Channel>> ChannelsChanged;
        public event EventHandler<Channel> CurrentChannelChanged;

        public string CurrentChannelId => _currentChannelId;
        public Channel CurrentChannel => _cachedChannels.FirstOrDefault(c => c.Id == _currentChannelId);

        public ChannelService(FirebaseService firebaseService, UserService userService)
        {
            _firebaseService = firebaseService;
            _userService = userService;
        }

        /// <summary>
        /// Initializes channels in the database if they don't exist
        /// </summary>
        public async Task InitializeDefaultChannels()
        {
            try
            {
                // Check if channels already exist
                var channels = await _firebaseService.GetAsync<Dictionary<string, Channel>>(Config.ChannelsPath);

                if (channels == null || channels.Count == 0)
                {
                    var defaultChannels = new Dictionary<string, Channel>();

                    foreach (var defaultChannel in Config.DefaultChannels)
                    {
                        defaultChannels.Add(defaultChannel.Key, new Channel
                        {
                            Id = defaultChannel.Key,
                            Name = defaultChannel.Value.Name,
                            Description = defaultChannel.Value.Description,
                            CreatedBy = "system",
                            CreatedAt = DateTimeOffset.UtcNow.ToUnixTimeMilliseconds(),
                            IsPrivate = false,
                            Members = new string[] { },
                            Topic = defaultChannel.Value.Description
                        });
                    }

                    await _firebaseService.PutAsync(Config.ChannelsPath, defaultChannels);
                }

                // Load channels
                await RefreshChannels();
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Error initializing default channels: {ex.Message}");
                throw;
            }
        }

        /// <summary>
        /// Gets all available channels
        /// </summary>
        public async Task RefreshChannels()
        {
            try
            {
                var channels = await _firebaseService.GetAsync<Dictionary<string, Channel>>(Config.ChannelsPath);

                if (channels != null)
                {
                    _cachedChannels = channels.Values.ToList();
                    ChannelsChanged?.Invoke(this, _cachedChannels);
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Error refreshing channels: {ex.Message}");
            }
        }

        /// <summary>
        /// Gets all available channels from cache
        /// </summary>
        public List<Channel> GetChannels()
        {
            return _cachedChannels;
        }

        /// <summary>
        /// Creates a new channel
        /// </summary>
        public async Task<Channel> CreateChannel(string name, string description, bool isPrivate = false, string[] members = null)
        {
            try
            {
                // Generate a safe channel ID
                string channelId = name.ToLower().Replace(" ", "-").Replace("#", "")
                    .Replace("@", "").Replace("&", "").Replace("?", "");

                // Check if channel already exists
                if (_cachedChannels.Any(c => c.Id == channelId))
                {
                    throw new Exception($"Channel #{name} already exists");
                }

                var channel = new Channel
                {
                    Id = channelId,
                    Name = name,
                    Description = description,
                    CreatedBy = _userService.CurrentUsername,
                    CreatedAt = DateTimeOffset.UtcNow.ToUnixTimeMilliseconds(),
                    IsPrivate = isPrivate,
                    Members = members ?? new string[] { _userService.CurrentUsername },
                    Topic = description
                };

                await _firebaseService.PutAsync($"{Config.ChannelsPath}/{channelId}", channel);

                // Update cached channels
                await RefreshChannels();

                return channel;
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Error creating channel: {ex.Message}");
                throw;
            }
        }

        /// <summary>
        /// Switch to a different channel
        /// </summary>
        public async Task SwitchChannel(string channelId)
        {
            // Validate the channel exists
            var channel = _cachedChannels.FirstOrDefault(c => c.Id == channelId);

            if (channel == null)
            {
                throw new Exception($"Channel {channelId} does not exist");
            }

            // Check if private and user is a member
            if (channel.IsPrivate && !channel.Members.Contains(_userService.CurrentUsername))
            {
                throw new Exception($"You don't have access to #{channel.Name}");
            }

            _currentChannelId = channelId;

            // Update user's current channel
            await _userService.SetCurrentChannel(channelId);

            CurrentChannelChanged?.Invoke(this, channel);
        }

        /// <summary>
        /// Update channel topic
        /// </summary>
        public async Task UpdateChannelTopic(string channelId, string topic)
        {
            try
            {
                if (!_cachedChannels.Any(c => c.Id == channelId))
                {
                    throw new Exception($"Channel {channelId} does not exist");
                }

                var updateData = new
                {
                    topic = topic
                };

                await _firebaseService.PatchAsync($"{Config.ChannelsPath}/{channelId}", updateData);

                // Update cached channels
                await RefreshChannels();
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Error updating channel topic: {ex.Message}");
                throw;
            }
        }

        /// <summary>
        /// Get channel by ID
        /// </summary>
        public Channel GetChannel(string channelId)
        {
            return _cachedChannels.FirstOrDefault(c => c.Id == channelId);
        }
    }
}