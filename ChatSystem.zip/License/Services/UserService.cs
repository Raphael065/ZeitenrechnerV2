﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Timers;
using FirebaseDiscordChat.Models;
using FirebaseDiscordChat.Utils;

namespace FirebaseDiscordChat.Services
{
    public class UserService
    {
        private readonly FirebaseService _firebaseService;
        private readonly Timer _heartbeatTimer;
        private User _currentUser;
        private List<User> _cachedUsers = new List<User>();
        private bool _isInitialized = false;
        private bool _isRefreshing = false;

        public event EventHandler<User> CurrentUserChanged;
        public event EventHandler<List<User>> ActiveUsersChanged;

        public string CurrentUsername => _currentUser?.Username;
        public User CurrentUser => _currentUser;

        public UserService(FirebaseService firebaseService)
        {
            _firebaseService = firebaseService;

            // Set up heartbeat timer
            _heartbeatTimer = new Timer(Config.HeartbeatInterval);
            _heartbeatTimer.Elapsed += async (s, e) => await UpdateHeartbeat();
        }

        /// <summary>
        /// Initializes the user service with the current user
        /// </summary>
        public async Task Initialize(string username, string displayName = null)
        {
            if (_isInitialized)
                return;

            try
            {
                // Check if user already exists
                var existingUser = await _firebaseService.GetAsync<User>($"{Config.UsersPath}/{username}");

                if (existingUser != null)
                {
                    _currentUser = existingUser;
                    _currentUser.Status = "online";
                    _currentUser.LastActive = DateTimeOffset.UtcNow.ToUnixTimeMilliseconds();
                }
                else
                {
                    // Create new user
                    _currentUser = new User
                    {
                        Username = username,
                        DisplayName = displayName ?? username,
                        Status = "online",
                        LastActive = DateTimeOffset.UtcNow.ToUnixTimeMilliseconds(),
                        JoinedAt = DateTimeOffset.UtcNow.ToUnixTimeMilliseconds(),
                        CurrentChannel = "general"
                    };
                }

                // Save user to Firebase
                await _firebaseService.PutAsync($"{Config.UsersPath}/{username}", _currentUser);

                // Start heartbeat
                _heartbeatTimer.Start();

                // Register shutdown handler
                Console.CancelKeyPress += async (s, e) =>
                {
                    e.Cancel = true;
                    await SetStatus("offline");
                    Environment.Exit(0);
                };

                _isInitialized = true;
                CurrentUserChanged?.Invoke(this, _currentUser);
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Error initializing user: {ex.Message}");
                throw;
            }
        }

        /// <summary>
        /// Updates the user's status
        /// </summary>
        public async Task SetStatus(string status)
        {
            if (_currentUser == null)
                return;

            _currentUser.Status = status;
            _currentUser.LastActive = DateTimeOffset.UtcNow.ToUnixTimeMilliseconds();

            var updateData = new
            {
                status = status,
                lastActive = _currentUser.LastActive
            };

            await _firebaseService.PatchAsync($"{Config.UsersPath}/{_currentUser.Username}", updateData);
            CurrentUserChanged?.Invoke(this, _currentUser);
        }

        /// <summary>
        /// Sets the user's custom status message
        /// </summary>
        public async Task SetCustomStatus(string customStatus)
        {
            if (_currentUser == null)
                return;

            _currentUser.CustomStatus = customStatus;

            var updateData = new
            {
                customStatus = customStatus,
                lastActive = DateTimeOffset.UtcNow.ToUnixTimeMilliseconds()
            };

            await _firebaseService.PatchAsync($"{Config.UsersPath}/{_currentUser.Username}", updateData);
            CurrentUserChanged?.Invoke(this, _currentUser);
        }

        /// <summary>
        /// Sets the current channel for the user
        /// </summary>
        public async Task SetCurrentChannel(string channelId)
        {
            if (_currentUser == null)
                return;

            _currentUser.CurrentChannel = channelId;

            var updateData = new
            {
                currentChannel = channelId,
                lastActive = DateTimeOffset.UtcNow.ToUnixTimeMilliseconds()
            };

            await _firebaseService.PatchAsync($"{Config.UsersPath}/{_currentUser.Username}", updateData);
            CurrentUserChanged?.Invoke(this, _currentUser);
        }

        /// <summary>
        /// Retrieves all active users - simplified version with better error handling
        /// </summary>
        public async Task<List<User>> GetActiveUsers()
        {
            // Prevent concurrent refreshes
            if (_isRefreshing)
                return _cachedUsers;

            _isRefreshing = true;

            try
            {
                // Create a hardcoded user list if empty
                if (_cachedUsers.Count == 0 && _currentUser != null)
                {
                    _cachedUsers.Add(_currentUser);
                }

                // Attempt to get users from Firebase
                try
                {
                    var users = await _firebaseService.GetAsync<Dictionary<string, User>>(Config.UsersPath);

                    if (users != null && users.Count > 0)
                    {
                        // Filter active users (not offline and active in the last 3 minutes)
                        long activeThreshold = DateTimeOffset.UtcNow.AddMinutes(-3).ToUnixTimeMilliseconds();
                        _cachedUsers = users.Values
                            .Where(u => u != null && u.Status != "offline" && u.LastActive > activeThreshold)
                            .OrderBy(u => u.Username)
                            .ToList();
                    }
                }
                catch (Exception ex)
                {
                    Console.WriteLine($"Warning: Error fetching users from Firebase: {ex.Message}");
                    // Continue with cached users
                }

                // Ensure current user is always in the list
                if (_currentUser != null && _cachedUsers.All(u => u.Username != _currentUser.Username))
                {
                    _cachedUsers.Add(_currentUser);
                }

                ActiveUsersChanged?.Invoke(this, _cachedUsers);
                _isRefreshing = false;
                return _cachedUsers;
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Error getting active users: {ex.Message}");
                _isRefreshing = false;
                return _cachedUsers; // Return cached users on error
            }
        }

        /// <summary>
        /// Gets a user by username
        /// </summary>
        public async Task<User> GetUser(string username)
        {
            // Return current user if requesting own profile
            if (_currentUser != null && _currentUser.Username == username)
                return _currentUser;

            // Try from cache first
            var cachedUser = _cachedUsers.FirstOrDefault(u => u.Username == username);
            if (cachedUser != null)
                return cachedUser;

            try
            {
                return await _firebaseService.GetAsync<User>($"{Config.UsersPath}/{username}");
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Error getting user: {ex.Message}");
                return null;
            }
        }

        /// <summary>
        /// Updates the user's heartbeat to show they're still active
        /// </summary>
        private async Task UpdateHeartbeat()
        {
            if (_currentUser == null)
                return;

            _currentUser.LastActive = DateTimeOffset.UtcNow.ToUnixTimeMilliseconds();

            var updateData = new
            {
                lastActive = _currentUser.LastActive
            };

            try
            {
                await _firebaseService.PatchAsync($"{Config.UsersPath}/{_currentUser.Username}", updateData);
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Error updating heartbeat: {ex.Message}");
                // Continue even if heartbeat fails
            }
        }
    }
}