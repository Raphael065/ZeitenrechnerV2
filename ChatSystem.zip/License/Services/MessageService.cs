﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using FirebaseDiscordChat.Models;
using FirebaseDiscordChat.Utils;

namespace FirebaseDiscordChat.Services
{
    public class MessageService
    {
        private readonly FirebaseService _firebaseService;
        private readonly UserService _userService;
        private Dictionary<string, Dictionary<string, ChatMessage>> _channelMessages = new Dictionary<string, Dictionary<string, ChatMessage>>();
        private long _lastSeenTimestamp = DateTimeOffset.UtcNow.ToUnixTimeMilliseconds();

        public event EventHandler<List<ChatMessage>> MessagesUpdated;

        public MessageService(FirebaseService firebaseService, UserService userService)
        {
            _firebaseService = firebaseService;
            _userService = userService;
        }

        /// <summary>
        /// Send a message to a channel
        /// </summary>
        public async Task<ChatMessage> SendMessage(string content, string channelId)
        {
            try
            {
                // Detect mentions (@username)
                var mentionPattern = new Regex(@"@(\w+)");
                var mentions = mentionPattern.Matches(content)
                    .Cast<Match>()
                    .Select(m => m.Groups[1].Value)
                    .ToArray();

                var message = new ChatMessage
                {
                    Username = _userService.CurrentUsername,
                    Content = content,
                    Timestamp = DateTimeOffset.UtcNow.ToUnixTimeMilliseconds(),
                    ChannelId = channelId,
                    MentionedUsers = mentions,
                    HasAttachment = false,
                    IsEdited = false
                };

                // Send to Firebase
                string messageId = await _firebaseService.PostAsync(Config.MessagesPath, message);

                // Update user's last active timestamp
                await _userService.SetStatus(_userService.CurrentUser.Status);

                // If message contains mentions, notify mentioned users
                if (mentions.Length > 0)
                {
                    foreach (var mention in mentions)
                    {
                        var mentionedUser = await _userService.GetUser(mention);
                        if (mentionedUser != null)
                        {
                            // In a real app, we would send a notification to the user
                            // For now, we just log it
                            Console.WriteLine($"Notification to {mention}: You were mentioned by {_userService.CurrentUsername}");
                        }
                    }
                }

                return message;
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Error sending message: {ex.Message}");
                throw;
            }
        }

        /// <summary>
        /// Get messages for a specific channel
        /// </summary>
        public async Task<List<ChatMessage>> GetChannelMessages(string channelId, int limit = 50)
        {
            try
            {
                // Fetch all messages (Firebase doesn't support complex queries)
                var allMessages = await _firebaseService.GetAsync<Dictionary<string, ChatMessage>>(Config.MessagesPath);

                if (allMessages == null)
                    return new List<ChatMessage>();

                // Update the cache with all messages
                foreach (var entry in allMessages)
                {
                    string msgChannelId = entry.Value.ChannelId;

                    if (!_channelMessages.ContainsKey(msgChannelId))
                    {
                        _channelMessages[msgChannelId] = new Dictionary<string, ChatMessage>();
                    }

                    _channelMessages[msgChannelId][entry.Key] = entry.Value;
                }

                // Filter by channel and get most recent messages
                if (!_channelMessages.ContainsKey(channelId))
                    return new List<ChatMessage>();

                var channelMessages = _channelMessages[channelId].Values
                    .OrderByDescending(m => m.Timestamp)
                    .Take(limit)
                    .OrderBy(m => m.Timestamp)
                    .ToList();

                // Update the last seen timestamp
                if (channelMessages.Any())
                {
                    _lastSeenTimestamp = Math.Max(_lastSeenTimestamp,
                        channelMessages.Max(m => m.Timestamp));
                }

                MessagesUpdated?.Invoke(this, channelMessages);
                return channelMessages;
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Error getting channel messages: {ex.Message}");
                return new List<ChatMessage>();
            }
        }

        /// <summary>
        /// Poll for new messages across all channels
        /// </summary>
        public async Task PollNewMessages()
        {
            try
            {
                // Get all messages with a timestamp greater than our last seen timestamp
                // This is inefficient, but Firebase Realtime Database doesn't have good query support
                var allMessages = await _firebaseService.GetAsync<Dictionary<string, ChatMessage>>(Config.MessagesPath);

                if (allMessages == null)
                    return;

                var newMessages = new Dictionary<string, List<ChatMessage>>();
                bool hasNewMessages = false;

                foreach (var entry in allMessages)
                {
                    var message = entry.Value;

                    // Check if this is a new message
                    if (message.Timestamp > _lastSeenTimestamp)
                    {
                        hasNewMessages = true;

                        string msgChannelId = message.ChannelId;

                        // Add to channel cache
                        if (!_channelMessages.ContainsKey(msgChannelId))
                        {
                            _channelMessages[msgChannelId] = new Dictionary<string, ChatMessage>();
                        }

                        _channelMessages[msgChannelId][entry.Key] = message;

                        // Add to new messages list
                        if (!newMessages.ContainsKey(msgChannelId))
                        {
                            newMessages[msgChannelId] = new List<ChatMessage>();
                        }

                        newMessages[msgChannelId].Add(message);

                        // Update last seen timestamp
                        _lastSeenTimestamp = Math.Max(_lastSeenTimestamp, message.Timestamp);
                    }
                }

                // Trigger events if there are new messages
                if (hasNewMessages)
                {
                    foreach (var channelId in newMessages.Keys)
                    {
                        var messages = _channelMessages[channelId].Values
                            .OrderBy(m => m.Timestamp)
                            .ToList();

                        MessagesUpdated?.Invoke(this, messages);
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Error polling for new messages: {ex.Message}");
            }
        }

        /// <summary>
        /// Formats message content with colors and formatting
        /// </summary>
        public string FormatMessageContent(string content)
        {
            if (string.IsNullOrEmpty(content))
                return string.Empty;

            // Process code blocks
            content = Regex.Replace(content, @"```(.*?)```", m =>
            {
                return $"\n[Code Block]:\n{m.Groups[1].Value}\n";
            }, RegexOptions.Singleline);

            // Process inline code
            content = Regex.Replace(content, @"`(.*?)`", m =>
            {
                return $"[{m.Groups[1].Value}]";
            });

            // Process bold text
            content = Regex.Replace(content, @"\*\*(.*?)\*\*", m =>
            {
                return $"*{m.Groups[1].Value}*";
            });

            // Process italic text
            content = Regex.Replace(content, @"\*(.*?)\*", m =>
            {
                return $"_{m.Groups[1].Value}_";
            });

            // Process mentions
            content = Regex.Replace(content, @"@(\w+)", m =>
            {
                return $"@{m.Groups[1].Value}";
            });

            // Process URLs
            content = Regex.Replace(content, @"(https?://[^\s]+)", m =>
            {
                return $"[Link: {m.Groups[1].Value}]";
            });

            // Process emojis
            var emojiMap = new Dictionary<string, string>
            {
                { ":smile:", "😊" },
                { ":laugh:", "😂" },
                { ":thumbsup:", "👍" },
                { ":thumbsdown:", "👎" },
                { ":heart:", "❤️" },
                { ":fire:", "🔥" },
                { ":tada:", "🎉" },
                { ":check:", "✅" },
                { ":x:", "❌" }
            };

            foreach (var emoji in emojiMap)
            {
                content = content.Replace(emoji.Key, emoji.Value);
            }

            return content;
        }

        /// <summary>
        /// Send a system message to a channel
        /// </summary>
        public async Task SendSystemMessage(string content, string channelId)
        {
            try
            {
                var message = new ChatMessage
                {
                    Username = "System",
                    Content = content,
                    Timestamp = DateTimeOffset.UtcNow.ToUnixTimeMilliseconds(),
                    ChannelId = channelId,
                    MentionedUsers = new string[0],
                    HasAttachment = false,
                    IsEdited = false
                };

                // Send to Firebase
                await _firebaseService.PostAsync(Config.MessagesPath, message);
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Error sending system message: {ex.Message}");
            }
        }

        /// <summary>
        /// Edit an existing message
        /// </summary>
        public async Task<bool> EditMessage(string messageId, string newContent)
        {
            try
            {
                // Check if we have the message in our cache
                string channelId = null;
                ChatMessage existingMessage = null;

                foreach (var channel in _channelMessages)
                {
                    if (channel.Value.ContainsKey(messageId))
                    {
                        channelId = channel.Key;
                        existingMessage = channel.Value[messageId];
                        break;
                    }
                }

                if (existingMessage == null)
                {
                    // Message not found in cache, try to get it from Firebase
                    existingMessage = await _firebaseService.GetAsync<ChatMessage>($"{Config.MessagesPath}/{messageId}");

                    if (existingMessage == null)
                        return false;

                    channelId = existingMessage.ChannelId;
                }

                // Only the original author can edit the message
                if (existingMessage.Username != _userService.CurrentUsername)
                    return false;

                // Update the message content
                existingMessage.Content = newContent;
                existingMessage.IsEdited = true;

                // Save to Firebase
                await _firebaseService.PatchAsync($"{Config.MessagesPath}/{messageId}", new
                {
                    content = newContent,
                    isEdited = true
                });

                // Update in cache
                if (!_channelMessages.ContainsKey(channelId))
                {
                    _channelMessages[channelId] = new Dictionary<string, ChatMessage>();
                }

                _channelMessages[channelId][messageId] = existingMessage;

                // Notify listeners
                var channelMessages = _channelMessages[channelId].Values
                    .OrderBy(m => m.Timestamp)
                    .ToList();

                MessagesUpdated?.Invoke(this, channelMessages);

                return true;
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Error editing message: {ex.Message}");
                return false;
            }
        }

        /// <summary>
        /// Delete a message
        /// </summary>
        public async Task<bool> DeleteMessage(string messageId)
        {
            try
            {
                // Check if we have the message in our cache
                string channelId = null;
                ChatMessage existingMessage = null;

                foreach (var channel in _channelMessages)
                {
                    if (channel.Value.ContainsKey(messageId))
                    {
                        channelId = channel.Key;
                        existingMessage = channel.Value[messageId];
                        break;
                    }
                }

                if (existingMessage == null)
                {
                    // Message not found in cache, try to get it from Firebase
                    existingMessage = await _firebaseService.GetAsync<ChatMessage>($"{Config.MessagesPath}/{messageId}");

                    if (existingMessage == null)
                        return false;

                    channelId = existingMessage.ChannelId;
                }

                // Only the original author can delete the message
                if (existingMessage.Username != _userService.CurrentUsername)
                    return false;

                // Delete from Firebase
                await _firebaseService.DeleteAsync($"{Config.MessagesPath}/{messageId}");

                // Remove from cache
                if (_channelMessages.ContainsKey(channelId) && _channelMessages[channelId].ContainsKey(messageId))
                {
                    _channelMessages[channelId].Remove(messageId);

                    // Notify listeners
                    var channelMessages = _channelMessages[channelId].Values
                        .OrderBy(m => m.Timestamp)
                        .ToList();

                    MessagesUpdated?.Invoke(this, channelMessages);
                }

                return true;
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Error deleting message: {ex.Message}");
                return false;
            }
        }

        /// <summary>
        /// Get message history count for a channel
        /// </summary>
        public int GetMessageCount(string channelId)
        {
            if (_channelMessages.ContainsKey(channelId))
            {
                return _channelMessages[channelId].Count;
            }

            return 0;
        }

        /// <summary>
        /// Search for messages containing specific text
        /// </summary>
        public List<ChatMessage> SearchMessages(string searchText, string channelId = null)
        {
            var results = new List<ChatMessage>();

            try
            {
                if (string.IsNullOrWhiteSpace(searchText))
                    return results;

                searchText = searchText.ToLower();

                // Search in the specified channel only
                if (!string.IsNullOrEmpty(channelId) && _channelMessages.ContainsKey(channelId))
                {
                    foreach (var message in _channelMessages[channelId].Values)
                    {
                        if (message.Content.ToLower().Contains(searchText) ||
                            message.Username.ToLower().Contains(searchText))
                        {
                            results.Add(message);
                        }
                    }
                }
                // Search across all channels
                else
                {
                    foreach (var channel in _channelMessages.Values)
                    {
                        foreach (var message in channel.Values)
                        {
                            if (message.Content.ToLower().Contains(searchText) ||
                                message.Username.ToLower().Contains(searchText))
                            {
                                results.Add(message);
                            }
                        }
                    }
                }

                // Sort by timestamp
                return results.OrderByDescending(m => m.Timestamp).ToList();
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Error searching messages: {ex.Message}");
                return results;
            }
        }
    }
}