﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using FirebaseDiscordChat.Models;
using FirebaseDiscordChat.Services;
using FirebaseDiscordChat.Utils;

namespace FirebaseDiscordChat.UI
{
    public class ChatRenderer
    {
        private readonly ChannelService _channelService;
        private readonly MessageService _messageService;

        public ChatRenderer(ChannelService channelService, MessageService messageService)
        {
            _channelService = channelService;
            _messageService = messageService;
        }

        /// <summary>
        /// Render the main chat area
        /// </summary>
        public void Render(int left, int top, int width, int height)
        {
            try
            {
                // Draw chat background
                DrawChatBackground(left, top, width, height);

                // Draw channel header
                DrawChannelHeader(left, top, width);

                // Draw messages
                DrawMessages(left, top + 2, width, height - 2);
            }
            catch (Exception ex)
            {
                Console.ForegroundColor = ConsoleColor.Red;
                Console.SetCursorPosition(left, top + height - 1);
                Console.WriteLine($"Chat Error: {ex.Message}");
                Console.ResetColor();
            }
        }

        private void DrawChatBackground(int left, int top, int width, int height)
        {
            Console.BackgroundColor = Config.Colors["message_bg"];
            Console.ForegroundColor = Config.Colors["message_fg"];

            string emptyLine = new string(' ', width);

            for (int y = 0; y < height; y++)
            {
                Console.SetCursorPosition(left, top + y);
                Console.Write(emptyLine);
            }
        }

        private void DrawChannelHeader(int left, int top, int width)
        {
            var currentChannel = _channelService.CurrentChannel;

            if (currentChannel == null)
                return;

            // Draw channel header background
            Console.BackgroundColor = Config.Colors["header_bg"];
            Console.ForegroundColor = Config.Colors["header_fg"];

            Console.SetCursorPosition(left, top);
            string header = $" #{currentChannel.Name}";
            header = header.PadRight(width);
            Console.Write(header);

            // Draw channel topic
            if (!string.IsNullOrEmpty(currentChannel.Topic))
            {
                Console.SetCursorPosition(left, top + 1);
                string topic = $" {currentChannel.Topic}";

                if (topic.Length > width - 2)
                {
                    topic = topic.Substring(0, width - 5) + "...";
                }

                topic = topic.PadRight(width);
                Console.Write(topic);
            }
        }

        private void DrawMessages(int left, int top, int width, int height)
        {
            var currentChannel = _channelService.CurrentChannel;

            if (currentChannel == null)
                return;

            // Fetch messages for the current channel
            var messages = _messageService.GetChannelMessages(currentChannel.Id, Config.MessageHistoryLimit).Result;

            if (messages.Count == 0)
            {
                // Show welcome message for empty channel
                Console.SetCursorPosition(left + 2, top + 2);
                Console.ForegroundColor = ConsoleColor.Gray;
                Console.Write($"Welcome to #{currentChannel.Name}!");

                Console.SetCursorPosition(left + 2, top + 3);
                Console.Write("This is the start of this channel.");
                return;
            }

            // Sort messages by timestamp
            messages = messages.OrderBy(m => m.Timestamp).ToList();

            // Only show messages that can fit in the view
            int maxMessagesToShow = height;
            int messagesToSkip = Math.Max(0, messages.Count - maxMessagesToShow);

            int currentLine = top;

            foreach (var message in messages.Skip(messagesToSkip))
            {
                // Check if we're out of view
                if (currentLine >= top + height)
                    break;

                // Format message with wrapping
                List<string> lines = FormatMessage(message, width);

                foreach (string line in lines)
                {
                    Console.SetCursorPosition(left, currentLine);
                    Console.Write(line);
                    currentLine++;

                    // Check if we're out of view after wrapping
                    if (currentLine >= top + height)
                        break;
                }
            }
        }

        private List<string> FormatMessage(ChatMessage message, int width)
        {
            List<string> lines = new List<string>();

            // Format first line with username and timestamp
            Console.ForegroundColor = Config.Colors["timestamp_fg"];
            string timestamp = message.FormattedTime;

            Console.ForegroundColor = Config.Colors["username_fg"];
            string username = message.Username;

            // Handle system messages differently
            if (username == "System")
            {
                Console.ForegroundColor = Config.Colors["system_message_fg"];
                string systemLine = $" [{timestamp}] {message.Content}";

                // Word wrap system message
                lines.AddRange(WrapText(systemLine, width));
                return lines;
            }

            // Format regular message
            string firstLine = $" [{timestamp}] {username}: ";
            int contentStartColumn = firstLine.Length;

            // Get formatted content
            string content = _messageService.FormatMessageContent(message.Content);

            // Create the first line with username and start of content
            if (contentStartColumn + content.Length <= width)
            {
                // Message fits on one line
                lines.Add(firstLine + content);
            }
            else
            {
                // Split content across multiple lines
                string firstLineContent = content.Substring(0, Math.Min(content.Length, width - contentStartColumn));
                lines.Add(firstLine + firstLineContent);

                // Wrap remaining content
                string remainingContent = content.Substring(firstLineContent.Length);
                string padding = new string(' ', contentStartColumn);

                var wrappedLines = WrapText(remainingContent, width - contentStartColumn);

                foreach (var line in wrappedLines)
                {
                    lines.Add(padding + line);
                }
            }

            return lines;
        }

        private List<string> WrapText(string text, int width)
        {
            List<string> lines = new List<string>();

            if (string.IsNullOrEmpty(text))
            {
                lines.Add(string.Empty);
                return lines;
            }

            // Simple word wrap algorithm
            int currentPosition = 0;

            while (currentPosition < text.Length)
            {
                int remainingLength = text.Length - currentPosition;

                if (remainingLength <= width)
                {
                    // Add the last piece
                    lines.Add(text.Substring(currentPosition));
                    break;
                }

                // Find a good breaking point
                int breakPoint = text.LastIndexOf(' ', currentPosition + width - 1, Math.Min(width, remainingLength));

                if (breakPoint <= currentPosition)
                {
                    // No good breaking point found, break at maximum width
                    breakPoint = currentPosition + width - 1;
                }

                // Add the line
                lines.Add(text.Substring(currentPosition, breakPoint - currentPosition));
                currentPosition = breakPoint + 1;
            }

            return lines;
        }
    }
}