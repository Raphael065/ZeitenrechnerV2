﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using FirebaseDiscordChat.Models;
using FirebaseDiscordChat.Services;
using FirebaseDiscordChat.Utils;

namespace FirebaseDiscordChat.UI
{
    public class SidebarRenderer
    {
        private readonly ChannelService _channelService;
        private readonly UserService _userService;

        public SidebarRenderer(ChannelService channelService, UserService userService)
        {
            _channelService = channelService;
            _userService = userService;
        }

        /// <summary>
        /// Render the sidebar with channels and users
        /// </summary>
        public void Render(int left, int top, int width, int height)
        {
            try
            {
                // Draw sidebar background
                DrawSidebarBackground(left, top, width, height);

                // Draw server name header
                DrawServerHeader(left, top, width);

                // Draw channels section
                DrawChannelsSection(left, top + 2, width);

                // Draw users section
                DrawUsersSection(left, top + height / 2, width, height - (height / 2) - 1);

                // Draw user status at bottom
                DrawUserStatus(left, top + height - 1, width);
            }
            catch (Exception ex)
            {
                Console.ForegroundColor = ConsoleColor.Red;
                Console.SetCursorPosition(left, top + height - 1);
                Console.WriteLine($"UI Error: {ex.Message}");
                Console.ResetColor();
            }
        }

        private void DrawSidebarBackground(int left, int top, int width, int height)
        {
            Console.BackgroundColor = Config.Colors["sidebar_bg"];
            Console.ForegroundColor = Config.Colors["sidebar_fg"];

            string emptyLine = new string(' ', width);

            for (int y = 0; y < height; y++)
            {
                Console.SetCursorPosition(left, top + y);
                Console.Write(emptyLine);
            }
        }

        private void DrawServerHeader(int left, int top, int width)
        {
            // Draw server name header
            Console.BackgroundColor = ConsoleColor.DarkBlue;
            Console.ForegroundColor = ConsoleColor.White;

            Console.SetCursorPosition(left, top);
            string serverName = "FIREBASE DISCORD";

            int padding = (width - serverName.Length) / 2;
            string header = new string(' ', padding) + serverName + new string(' ', width - padding - serverName.Length);

            Console.Write(header);

            // Draw separator line
            Console.BackgroundColor = Config.Colors["sidebar_bg"];
            Console.ForegroundColor = ConsoleColor.Gray;

            Console.SetCursorPosition(left, top + 1);
            Console.Write(new string('═', width));
        }

        private void DrawChannelsSection(int left, int top, int width)
        {
            Console.BackgroundColor = Config.Colors["sidebar_bg"];

            // Draw channels header
            Console.ForegroundColor = ConsoleColor.Gray;
            Console.SetCursorPosition(left + 2, top);
            Console.Write("CHANNELS");

            // Get channels
            var channels = _channelService.GetChannels();
            string currentChannelId = _channelService.CurrentChannelId;

            // Draw channel list
            int channelTop = top + 1;

            foreach (var channel in channels)
            {
                if (channelTop > top + 15) // Limit number of channels to display
                    break;

                Console.SetCursorPosition(left + 2, channelTop);

                // Highlight current channel
                if (channel.Id == currentChannelId)
                {
                    Console.ForegroundColor = Config.Colors["active_channel_fg"];
                    Console.Write($"# {channel.Name} ←");
                }
                else
                {
                    Console.ForegroundColor = Config.Colors["inactive_channel_fg"];
                    Console.Write($"# {channel.Name}");
                }

                channelTop++;
            }

            // Draw create channel hint
            Console.ForegroundColor = ConsoleColor.Gray;
            Console.SetCursorPosition(left + 2, channelTop + 1);
            Console.Write("/create <name> - new channel");
        }

        private void DrawUsersSection(int left, int top, int width, int height)
        {
            Console.BackgroundColor = Config.Colors["sidebar_bg"];

            // Draw users header
            Console.ForegroundColor = ConsoleColor.Gray;
            Console.SetCursorPosition(left + 2, top);
            Console.Write("ONLINE USERS");

            // Get active users
            var users = _userService.GetActiveUsers().Result;

            // Draw separator line
            Console.SetCursorPosition(left, top + 1);
            Console.Write(new string('─', width));

            // Draw user list
            int userTop = top + 2;

            foreach (var user in users)
            {
                if (userTop >= top + height - 1)
                    break;

                Console.SetCursorPosition(left + 2, userTop);

                // Set status color
                if (Config.StatusColors.ContainsKey(user.Status))
                {
                    Console.ForegroundColor = Config.StatusColors[user.Status];
                }
                else
                {
                    Console.ForegroundColor = ConsoleColor.Gray;
                }

                // Display user with appropriate status icon
                string displayName = user.DisplayName ?? user.Username;

                if (displayName.Length > width - 6)
                {
                    displayName = displayName.Substring(0, width - 9) + "...";
                }

                Console.Write($"{user.StatusIcon} {displayName}");

                // Show custom status if present
                if (!string.IsNullOrEmpty(user.CustomStatus))
                {
                    userTop++;
                    Console.ForegroundColor = ConsoleColor.DarkGray;
                    Console.SetCursorPosition(left + 4, userTop);

                    string customStatus = user.CustomStatus;
                    if (customStatus.Length > width - 6)
                    {
                        customStatus = customStatus.Substring(0, width - 9) + "...";
                    }

                    Console.Write(customStatus);
                }

                userTop++;
            }

            // Show total user count
            int onlineCount = users.Count(u => u.Status == "online");
            int totalCount = users.Count;

            // Add some space before user count
            Console.SetCursorPosition(left, top + height - 3);
            Console.Write(new string('─', width));

            Console.ForegroundColor = ConsoleColor.Gray;
            Console.SetCursorPosition(left + 2, top + height - 2);
            Console.Write($"{onlineCount} online, {totalCount} total");
        }

        private void DrawUserStatus(int left, int top, int width)
        {
            var currentUser = _userService.CurrentUser;

            if (currentUser == null)
                return;

            // Draw user status bar
            Console.BackgroundColor = ConsoleColor.DarkGray;
            Console.ForegroundColor = ConsoleColor.White;

            Console.SetCursorPosition(left, top);

            // Set status color
            if (Config.StatusColors.ContainsKey(currentUser.Status))
            {
                Console.ForegroundColor = Config.StatusColors[currentUser.Status];
            }

            string statusBar = $" {currentUser.StatusIcon} {currentUser.DisplayName ?? currentUser.Username}";

            // Display status text if present
            if (!string.IsNullOrEmpty(currentUser.CustomStatus))
            {
                string customStatus = currentUser.CustomStatus;
                int maxLength = width - statusBar.Length - 3;

                if (customStatus.Length > maxLength)
                {
                    customStatus = customStatus.Substring(0, maxLength - 3) + "...";
                }

                statusBar += $" - {customStatus}";
            }

            // Ensure the status bar doesn't exceed the width
            if (statusBar.Length > width)
            {
                statusBar = statusBar.Substring(0, width - 3) + "...";
            }
            else
            {
                statusBar = statusBar.PadRight(width);
            }

            Console.Write(statusBar);
            Console.ResetColor();
        }
    }
}