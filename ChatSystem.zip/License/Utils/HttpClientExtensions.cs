﻿using System;
using System.Net.Http;
using System.Threading;
using System.Threading.Tasks;

namespace FirebaseDiscordChat.Utils
{
    public static class HttpClientExtensions
    {
        /// <summary>
        /// Sends a PATCH request to the specified URI with the given content
        /// </summary>
        public static Task<HttpResponseMessage> PatchAsync(this HttpClient client, string requestUri, HttpContent content)
        {
            return client.PatchAsync(requestUri, content, CancellationToken.None);
        }

        /// <summary>
        /// Sends a PATCH request with a cancellation token to the specified URI with the given content
        /// </summary>
        public static Task<HttpResponseMessage> PatchAsync(this HttpClient client, string requestUri, HttpContent content, CancellationToken cancellationToken)
        {
            var method = new HttpMethod("PATCH");
            var request = new HttpRequestMessage(method, requestUri)
            {
                Content = content
            };

            return client.SendAsync(request, cancellationToken);
        }
    }
}