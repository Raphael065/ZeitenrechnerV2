﻿using System;
using System.Linq;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using FirebaseDiscordChat.Services;
using FirebaseDiscordChat.Utils;

namespace FirebaseDiscordChat.Utils
{
    public class CommandHandler
    {
        private readonly ChannelService _channelService;
        private readonly UserService _userService;
        private readonly MessageService _messageService;
        private readonly FirebaseService _firebaseService;

        public CommandHandler(ChannelService channelService, UserService userService, MessageService messageService, FirebaseService firebaseService)
        {
            _channelService = channelService;
            _userService = userService;
            _messageService = messageService;
            _firebaseService = firebaseService;
        }

        /// <summary>
        /// Process a command entered by the user
        /// </summary>
        public async Task<(bool Success, string Message)> ProcessCommand(string input)
        {
            if (string.IsNullOrWhiteSpace(input) || !input.StartsWith("/"))
                return (false, "Not a command");

            // Split into command and arguments
            var match = Regex.Match(input, @"^/(\w+)(?:\s+(.*))?$");

            if (!match.Success)
                return (false, "Invalid command format");

            string command = match.Groups[1].Value.ToLower();
            string args = match.Groups[2].Success ? match.Groups[2].Value : string.Empty;

            try
            {
                switch (command)
                {
                    case "join":
                    case "j":
                        return await HandleJoinChannel(args);

                    case "create":
                    case "createchannel":
                    case "cc":
                        return await HandleCreateChannel(args);

                    case "nick":
                    case "nickname":
                        return await HandleSetNickname(args);

                    case "status":
                    case "setstatus":
                        return await HandleSetStatus(args);

                    case "online":
                        return await HandleSetStatus("online");

                    case "away":
                        return await HandleSetStatus("away");

                    case "dnd":
                    case "busy":
                        return await HandleSetStatus("dnd");

                    case "topic":
                    case "settopic":
                        return await HandleSetTopic(args);

                    case "list":
                    case "channels":
                        return await HandleListChannels();

                    case "users":
                    case "members":
                        return await HandleListUsers();

                    case "help":
                        return ShowHelp();

                    case "msg":
                    case "dm":
                    case "whisper":
                        return await HandleDirectMessage(args);

                    case "clear":
                    case "cls":
                        return (true, "clear");

                    case "search":
                        return await HandleSearchMessages(args);

                    case "edit":
                        return await HandleEditMessage(args);

                    case "delete":
                    case "del":
                        return await HandleDeleteMessage(args);

                    default:
                        return (false, $"Unknown command: /{command}. Type /help for a list of commands.");
                }
            }
            catch (Exception ex)
            {
                return (false, $"Error: {ex.Message}");
            }
        }

        private async Task<(bool, string)> HandleJoinChannel(string args)
        {
            if (string.IsNullOrWhiteSpace(args))
                return (false, "Usage: /join <channel_name>");

            var channels = _channelService.GetChannels();
            var channel = channels.FirstOrDefault(c =>
                c.Name.Equals(args, StringComparison.OrdinalIgnoreCase) ||
                c.Id.Equals(args, StringComparison.OrdinalIgnoreCase));

            if (channel == null)
                return (false, $"Channel '{args}' not found. Use /list to see available channels.");

            await _channelService.SwitchChannel(channel.Id);

            // Send a system message that user joined
            await _messageService.SendSystemMessage(
                $"{_userService.CurrentUser.DisplayName} joined the channel",
                channel.Id);

            return (true, $"Joined channel #{channel.Name}");
        }

        private async Task<(bool, string)> HandleCreateChannel(string args)
        {
            if (string.IsNullOrWhiteSpace(args))
                return (false, "Usage: /create <channel_name> [description]");

            var parts = args.Split(new[] { ' ' }, 2);
            string name = parts[0];
            string description = parts.Length > 1 ? parts[1] : $"{name} channel";

            var channel = await _channelService.CreateChannel(name, description);
            await _channelService.SwitchChannel(channel.Id);

            // Send a system message that channel was created
            await _messageService.SendSystemMessage(
                $"Channel created by {_userService.CurrentUser.DisplayName}",
                channel.Id);

            return (true, $"Created and joined channel #{channel.Name}");
        }

        private async Task<(bool, string)> HandleSetNickname(string nickname)
        {
            if (string.IsNullOrWhiteSpace(nickname))
                return (false, "Usage: /nick <new_nickname>");

            var user = _userService.CurrentUser;
            user.DisplayName = nickname;

            // Using the now-declared _firebaseService field
            await _firebaseService.PatchAsync($"{Config.UsersPath}/{user.Username}", new { displayName = nickname });

            return (true, $"Nickname changed to {nickname}");
        }

        private async Task<(bool, string)> HandleSetStatus(string status)
        {
            status = status.ToLower();

            switch (status)
            {
                case "online":
                case "away":
                case "dnd":
                case "offline":
                    await _userService.SetStatus(status);
                    return (true, $"Status set to {status}");

                default:
                    // Set custom status
                    await _userService.SetCustomStatus(status);
                    return (true, $"Custom status set to: {status}");
            }
        }

        private async Task<(bool, string)> HandleSetTopic(string args)
        {
            if (string.IsNullOrWhiteSpace(args))
                return (false, "Usage: /topic <new_topic>");

            var currentChannel = _channelService.CurrentChannel;

            if (currentChannel == null)
                return (false, "No active channel");

            await _channelService.UpdateChannelTopic(currentChannel.Id, args);

            // Send a system message that topic was changed
            await _messageService.SendSystemMessage(
                $"{_userService.CurrentUser.DisplayName} changed the channel topic to: {args}",
                currentChannel.Id);

            return (true, $"Channel topic updated");
        }

        private async Task<(bool, string)> HandleListChannels()
        {
            var channels = _channelService.GetChannels();

            if (channels.Count == 0)
                return (true, "No channels available");

            string channelList = "Available Channels:\n";

            foreach (var channel in channels)
            {
                channelList += $"#{channel.Name} - {channel.Description}\n";
            }

            return (true, channelList);
        }

        private async Task<(bool, string)> HandleListUsers()
        {
            var users = await _userService.GetActiveUsers();

            if (users.Count == 0)
                return (true, "No active users");

            string userList = "Active Users:\n";

            foreach (var user in users)
            {
                string statusIcon = user.StatusIcon;
                string displayName = string.IsNullOrEmpty(user.CustomStatus)
                    ? user.DisplayName
                    : $"{user.DisplayName} - {user.CustomStatus}";

                userList += $"{statusIcon} {displayName}\n";
            }

            return (true, userList);
        }

        // Fixed help function - now returns as a tuple for proper processing
        private (bool, string) ShowHelp()
        {
            string helpText = @"Available Commands:

Channel Management:
  /join <channel>         - Join a specific channel
  /create <name> [desc]   - Create a new channel
  /topic <new_topic>      - Set the channel topic
  /list                   - List all available channels

User Settings:
  /nick <nickname>        - Change your display name
  /status <status>        - Set a custom status message
  /online                 - Set status to online
  /away                   - Set status to away
  /dnd                    - Set status to do not disturb
  
User Interaction:
  /users                  - List all active users
  /msg <user> <message>   - Send a direct message
  
Message Management:
  /edit <message_id> <new_text> - Edit your message
  /delete <message_id>    - Delete your message
  /search <text>          - Search for messages
  
Utilities:
  /clear                  - Clear the chat display
  /help                   - Show this help message";

            return (true, helpText);
        }

        private async Task<(bool, string)> HandleDirectMessage(string args)
        {
            if (string.IsNullOrWhiteSpace(args))
                return (false, "Usage: /msg <username> <message>");

            var parts = args.Split(new[] { ' ' }, 2);

            if (parts.Length < 2)
                return (false, "Usage: /msg <username> <message>");

            string targetUsername = parts[0];
            string message = parts[1];

            // Check if user exists
            var targetUser = await _userService.GetUser(targetUsername);

            if (targetUser == null)
                return (false, $"User '{targetUsername}' not found");

            // Create DM channel ID (consistently by sorting usernames)
            string[] usernames = new[] { _userService.CurrentUsername, targetUsername };
            Array.Sort(usernames);
            string dmChannelId = $"dm-{string.Join("-", usernames)}";

            // Check if DM channel exists, if not create it
            var channels = _channelService.GetChannels();
            var dmChannel = channels.FirstOrDefault(c => c.Id == dmChannelId);

            if (dmChannel == null)
            {
                // Create new DM channel
                dmChannel = await _channelService.CreateChannel(
                    $"DM with {targetUser.DisplayName ?? targetUser.Username}",
                    "Direct Message Channel",
                    true,
                    new[] { _userService.CurrentUsername, targetUsername });
            }

            // Switch to DM channel and send message
            await _channelService.SwitchChannel(dmChannel.Id);
            await _messageService.SendMessage(message, dmChannel.Id);

            return (true, $"Sent DM to {targetUser.DisplayName ?? targetUser.Username}");
        }

        private async Task<(bool, string)> HandleSearchMessages(string searchText)
        {
            if (string.IsNullOrWhiteSpace(searchText))
                return (false, "Usage: /search <text>");

            var currentChannel = _channelService.CurrentChannel;

            if (currentChannel == null)
                return (false, "No active channel");

            var results = _messageService.SearchMessages(searchText, currentChannel.Id);

            if (results.Count == 0)
                return (true, $"No messages found containing '{searchText}'");

            string resultText = $"Search results for '{searchText}':\n";

            foreach (var message in results.Take(5)) // Limit to 5 results
            {
                string preview = message.Content;
                if (preview.Length > 50)
                    preview = preview.Substring(0, 47) + "...";

                resultText += $"[{message.FormattedTime}] {message.Username}: {preview}\n";
            }

            if (results.Count > 5)
                resultText += $"...and {results.Count - 5} more results.";

            return (true, resultText);
        }

        private async Task<(bool, string)> HandleEditMessage(string args)
        {
            if (string.IsNullOrWhiteSpace(args))
                return (false, "Usage: /edit <message_id> <new_text>");

            var parts = args.Split(new[] { ' ' }, 2);

            if (parts.Length < 2)
                return (false, "Usage: /edit <message_id> <new_text>");

            string messageId = parts[0];
            string newContent = parts[1];

            bool success = await _messageService.EditMessage(messageId, newContent);

            if (success)
                return (true, "Message edited successfully.");
            else
                return (false, "Failed to edit message. Make sure you are the author and the message ID is correct.");
        }

        private async Task<(bool, string)> HandleDeleteMessage(string messageId)
        {
            if (string.IsNullOrWhiteSpace(messageId))
                return (false, "Usage: /delete <message_id>");

            bool success = await _messageService.DeleteMessage(messageId);

            if (success)
                return (true, "Message deleted successfully.");
            else
                return (false, "Failed to delete message. Make sure you are the author and the message ID is correct.");
        }
    }
}