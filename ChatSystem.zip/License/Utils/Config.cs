﻿using System;
using System.Collections.Generic;

namespace FirebaseDiscordChat.Utils
{
    public static class Config
    {
        // Firebase configuration
        public const string FirebaseUrl = "https://zeitenrechner-ebd4c-default-rtdb.europe-west1.firebasedatabase.app";
        public const string MessagesPath = "/messages";
        public const string ChannelsPath = "/channels";
        public const string UsersPath = "/users";

        // UI configuration
        public const int SidebarWidth = 26;
        public const int MessageHistoryLimit = 50;
        public const int UserPollingInterval = 10000; // 10 seconds
        public const int MessagePollingInterval = 1000; // 1 second
        public const int UserInactiveTimeout = 180000; // 3 minutes in milliseconds
        public const int HeartbeatInterval = 30000; // 30 seconds

        // Colors
        public static readonly Dictionary<string, ConsoleColor> Colors = new Dictionary<string, ConsoleColor>
        {
            { "sidebar_bg", ConsoleColor.DarkBlue },
            { "sidebar_fg", ConsoleColor.White },
            { "header_bg", ConsoleColor.DarkGray },
            { "header_fg", ConsoleColor.White },
            { "input_bg", ConsoleColor.Black },
            { "input_fg", ConsoleColor.White },
            { "message_bg", ConsoleColor.Black },
            { "message_fg", ConsoleColor.White },
            { "timestamp_fg", ConsoleColor.DarkGray },
            { "username_fg", ConsoleColor.Cyan },
            { "system_message_fg", ConsoleColor.Yellow },
            { "active_channel_fg", ConsoleColor.Green },
            { "inactive_channel_fg", ConsoleColor.Gray },
            { "error_fg", ConsoleColor.Red }
        };

        // Status configuration
        public static readonly Dictionary<string, ConsoleColor> StatusColors = new Dictionary<string, ConsoleColor>
        {
            { "online", ConsoleColor.Green },
            { "away", ConsoleColor.Yellow },
            { "dnd", ConsoleColor.Red },
            { "offline", ConsoleColor.DarkGray }
        };

        // Default channels
        public static readonly Dictionary<string, (string Name, string Description)> DefaultChannels =
            new Dictionary<string, (string, string)>
        {
            { "general", ("General", "General discussion") },
            { "random", ("Random", "Random topics") },
            { "help", ("Help", "Get assistance here") },
            { "announcements", ("Announcements", "Important updates") }
        };
    }
}