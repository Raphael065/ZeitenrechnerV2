﻿using System;
using Newtonsoft.Json;

namespace FirebaseDiscordChat.Models
{
    public class Channel
    {
        [JsonProperty("id")]
        public string Id { get; set; }

        [JsonProperty("name")]
        public string Name { get; set; }

        [JsonProperty("description")]
        public string Description { get; set; }

        [JsonProperty("createdBy")]
        public string CreatedBy { get; set; }

        [JsonProperty("createdAt")]
        public long CreatedAt { get; set; }

        [JsonProperty("isPrivate")]
        public bool IsPrivate { get; set; }

        [JsonProperty("members")]
        public string[] Members { get; set; }

        [JsonProperty("topic")]
        public string Topic { get; set; }

        [JsonIgnore]
        public DateTime CreatedAtDateTime => DateTimeOffset.FromUnixTimeMilliseconds(CreatedAt).ToLocalTime().DateTime;

        [JsonIgnore]
        public string DisplayName => IsPrivate ? "🔒 " + Name : "# " + Name;
    }
}