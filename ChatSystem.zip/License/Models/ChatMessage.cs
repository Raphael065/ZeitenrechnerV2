﻿using System;
using Newtonsoft.Json;

namespace FirebaseDiscordChat.Models
{
    public class ChatMessage
    {
        [JsonProperty("username")]
        public string Username { get; set; }

        [JsonProperty("content")]
        public string Content { get; set; }

        [JsonProperty("timestamp")]
        public long Timestamp { get; set; }

        [JsonProperty("channelId")]
        public string ChannelId { get; set; }

        [JsonProperty("mentionedUsers")]
        public string[] MentionedUsers { get; set; }

        [JsonProperty("hasAttachment")]
        public bool HasAttachment { get; set; }

        [JsonProperty("isEdited")]
        public bool IsEdited { get; set; }

        [JsonIgnore]
        public DateTime LocalTime => DateTimeOffset.FromUnixTimeMilliseconds(Timestamp).ToLocalTime().DateTime;

        [JsonIgnore]
        public string FormattedTime => LocalTime.ToString("HH:mm:ss");
    }
}