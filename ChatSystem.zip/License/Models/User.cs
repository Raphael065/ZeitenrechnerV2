﻿using System;
using Newtonsoft.Json;
using Newtonsoft.Json.Converters;

namespace FirebaseDiscordChat.Models
{
    public class User
    {
        [JsonProperty("username")]
        public string Username { get; set; }

        [JsonProperty("displayName")]
        public string DisplayName { get; set; }

        [JsonProperty("status")]
        public string Status { get; set; } // "online", "away", "dnd", "offline"

        [JsonProperty("lastActive")]
        public long LastActive { get; set; }

        [JsonProperty("customStatus")]
        public string CustomStatus { get; set; }

        [JsonProperty("avatarColor")]
        public string AvatarColor { get; set; }

        [JsonProperty("joinedAt")]
        public long JoinedAt { get; set; }

        [JsonProperty("currentChannel")]
        public string CurrentChannel { get; set; }

        [JsonIgnore]
        public DateTime LastActiveDateTime => DateTimeOffset.FromUnixTimeMilliseconds(LastActive).ToLocalTime().DateTime;

        [JsonIgnore]
        public bool IsActive => (DateTimeOffset.UtcNow.ToUnixTimeMilliseconds() - LastActive) < 120000; // 2 minutes

        [JsonIgnore]
        public string StatusIcon
        {
            get
            {
                if (Status == null) return "⚪";
                switch (Status.ToLower())
                {
                    case "online":
                        return "🟢";
                    case "away":
                        return "🟡";
                    case "dnd":
                        return "🔴";
                    case "offline":
                        return "⚫";
                    default:
                        return "⚪";
                }
            }
        }

        public User()
        {
            // Set default values
            Status = "online";
            LastActive = DateTimeOffset.UtcNow.ToUnixTimeMilliseconds();
            JoinedAt = DateTimeOffset.UtcNow.ToUnixTimeMilliseconds();
            AvatarColor = GetRandomColor();
            CurrentChannel = "general";
        }

        private string GetRandomColor()
        {
            string[] colors = { "red", "blue", "green", "purple", "orange", "teal", "pink", "yellow" };
            return colors[new Random().Next(colors.Length)];
        }
    }
}