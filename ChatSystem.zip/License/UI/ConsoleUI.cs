﻿using System;
using System.Linq;
using System.Threading.Tasks;
using FirebaseDiscordChat.Models;
using FirebaseDiscordChat.Services;
using FirebaseDiscordChat.Utils;

namespace FirebaseDiscordChat.UI
{
    public class ConsoleUI
    {
        private readonly ChannelService _channelService;
        private readonly UserService _userService;
        private readonly MessageService _messageService;
        private readonly CommandHandler _commandHandler;

        private readonly SidebarRenderer _sidebarRenderer;
        private readonly ChatRenderer _chatRenderer;

        private int _consoleWidth;
        private int _consoleHeight;
        private bool _isRefreshing = false;
        private string _inputBuffer = string.Empty;
        private int _inputCursorPosition = 0;
        private bool _isShowingHelp = false;

        public ConsoleUI(
            ChannelService channelService,
            UserService userService,
            MessageService messageService,
            CommandHandler commandHandler)
        {
            _channelService = channelService;
            _userService = userService;
            _messageService = messageService;
            _commandHandler = commandHandler;

            _sidebarRenderer = new SidebarRenderer(channelService, userService);
            _chatRenderer = new ChatRenderer(channelService, messageService);

            // Subscribe to events
            _channelService.ChannelsChanged += (s, e) => RefreshUI();
            _channelService.CurrentChannelChanged += (s, e) => RefreshUI();
            _userService.ActiveUsersChanged += (s, e) => RefreshUI();
            _messageService.MessagesUpdated += (s, e) => RefreshUI();
        }

        /// <summary>
        /// Initialize the console UI
        /// </summary>
        public void Initialize()
        {
            try
            {
                Console.Title = "Discord-like Firebase Chat";
                Console.CursorVisible = false;
                Console.Clear();

                _consoleWidth = Console.WindowWidth;
                _consoleHeight = Console.WindowHeight;

                // Handle console resize
                Console.SetBufferSize(Console.WindowWidth, Console.WindowHeight);
                Console.CancelKeyPress += (s, e) =>
                {
                    Console.CursorVisible = true;
                    Console.ResetColor();
                };
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Error initializing console UI: {ex.Message}");
            }
        }

        /// <summary>
        /// Draw the complete UI
        /// </summary>
        public async Task RefreshUI()
        {
            if (_isRefreshing)
                return;

            _isRefreshing = true;

            try
            {
                // Store console dimensions
                _consoleWidth = Console.WindowWidth;
                _consoleHeight = Console.WindowHeight;

                Console.Clear();

                // Draw sidebar
                _sidebarRenderer.Render(0, 0, Config.SidebarWidth, _consoleHeight);

                // Draw main area
                if (!_isShowingHelp)
                {
                    _chatRenderer.Render(Config.SidebarWidth + 1, 0, _consoleWidth - Config.SidebarWidth - 1, _consoleHeight - 2);
                }

                // Draw input area
                DrawInputArea();

                // Restore cursor position for text input
                RestoreCursorToInput();
            }
            catch (Exception ex)
            {
                LogError($"Error refreshing UI: {ex.Message}");
            }

            _isRefreshing = false;
        }

        /// <summary>
        /// Start the main UI loop
        /// </summary>
        public async Task StartUILoop()
        {
            await RefreshUI();

            while (true)
            {
                if (Console.KeyAvailable)
                {
                    var key = Console.ReadKey(true);

                    // If help is showing, any key dismisses it
                    if (_isShowingHelp)
                    {
                        _isShowingHelp = false;
                        await RefreshUI();
                    }
                    else
                    {
                        await HandleKeyPress(key);
                    }
                }

                await Task.Delay(50);
            }
        }

        /// <summary>
        /// Display login form and get username
        /// </summary>
        public string ShowLoginForm()
        {
            Console.Clear();
            Console.CursorVisible = true;

            DrawBanner();

            Console.WriteLine("\n\n");
            Console.Write("Enter your username: ");
            string username = Console.ReadLine();

            Console.Write("Enter display name (or press Enter to use username): ");
            string displayName = Console.ReadLine();

            if (string.IsNullOrWhiteSpace(displayName))
                displayName = username;

            Console.WriteLine("\nConnecting to Discord-like Firebase Chat...");

            return username;
        }

        private void DrawBanner()
        {
            Console.ForegroundColor = ConsoleColor.Cyan;
            Console.WriteLine(@"
╔══════════════════════════════════════════════════════════════╗
║                                                              ║
║   ███████╗██╗██████╗ ███████╗██████╗  █████╗ ███████╗███████╗  ║
║   ██╔════╝██║██╔══██╗██╔════╝██╔══██╗██╔══██╗██╔════╝██╔════╝  ║
║   █████╗  ██║██████╔╝█████╗  ██████╔╝███████║███████╗█████╗    ║
║   ██╔══╝  ██║██╔══██╗██╔══╝  ██╔══██╗██╔══██║╚════██║██╔══╝    ║
║   ██║     ██║██║  ██║███████╗██████╔╝██║  ██║███████║███████╗  ║
║   ╚═╝     ╚═╝╚═╝  ╚═╝╚══════╝╚═════╝ ╚═╝  ╚═╝╚══════╝╚══════╝  ║
║                                                              ║
║   ██████╗ ██╗███████╗ ██████╗ ██████╗ ██████╗ ██████╗        ║
║   ██╔══██╗██║██╔════╝██╔════╝██╔═══██╗██╔══██╗██╔══██╗       ║
║   ██║  ██║██║███████╗██║     ██║   ██║██████╔╝██║  ██║       ║
║   ██║  ██║██║╚════██║██║     ██║   ██║██╔══██╗██║  ██║       ║
║   ██████╔╝██║███████║╚██████╗╚██████╔╝██║  ██║██████╔╝       ║
║   ╚═════╝ ╚═╝╚══════╝ ╚═════╝ ╚═════╝ ╚═╝  ╚═╝╚═════╝        ║
║                                                              ║
╚══════════════════════════════════════════════════════════════╝
");
            Console.ResetColor();
        }

        private async Task HandleKeyPress(ConsoleKeyInfo keyInfo)
        {
            switch (keyInfo.Key)
            {
                case ConsoleKey.Enter:
                    await ProcessInput();
                    break;

                case ConsoleKey.Backspace:
                    if (_inputBuffer.Length > 0 && _inputCursorPosition > 0)
                    {
                        _inputBuffer = _inputBuffer.Remove(_inputCursorPosition - 1, 1);
                        _inputCursorPosition--;
                        DrawInputArea();
                        RestoreCursorToInput();
                    }
                    break;

                case ConsoleKey.Delete:
                    if (_inputBuffer.Length > 0 && _inputCursorPosition < _inputBuffer.Length)
                    {
                        _inputBuffer = _inputBuffer.Remove(_inputCursorPosition, 1);
                        DrawInputArea();
                        RestoreCursorToInput();
                    }
                    break;

                case ConsoleKey.LeftArrow:
                    if (_inputCursorPosition > 0)
                    {
                        _inputCursorPosition--;
                        RestoreCursorToInput();
                    }
                    break;

                case ConsoleKey.RightArrow:
                    if (_inputCursorPosition < _inputBuffer.Length)
                    {
                        _inputCursorPosition++;
                        RestoreCursorToInput();
                    }
                    break;

                case ConsoleKey.Home:
                    _inputCursorPosition = 0;
                    RestoreCursorToInput();
                    break;

                case ConsoleKey.End:
                    _inputCursorPosition = _inputBuffer.Length;
                    RestoreCursorToInput();
                    break;

                case ConsoleKey.Escape:
                    _inputBuffer = string.Empty;
                    _inputCursorPosition = 0;
                    DrawInputArea();
                    RestoreCursorToInput();
                    break;

                case ConsoleKey.Tab:
                    // Auto-complete for channel names and usernames
                    await HandleTabComplete();
                    break;

                default:
                    // Handle regular character input
                    if (!char.IsControl(keyInfo.KeyChar))
                    {
                        _inputBuffer = _inputBuffer.Insert(_inputCursorPosition, keyInfo.KeyChar.ToString());
                        _inputCursorPosition++;
                        DrawInputArea();
                        RestoreCursorToInput();
                    }
                    break;
            }
        }

        private async Task HandleTabComplete()
        {
            if (_inputBuffer.StartsWith("/join ") || _inputBuffer.StartsWith("/j "))
            {
                // Auto-complete channel name
                string prefix = _inputBuffer.Contains(" ") ? _inputBuffer.Split(' ')[1] : "";

                if (!string.IsNullOrEmpty(prefix))
                {
                    var channels = _channelService.GetChannels();
                    var match = channels.FirstOrDefault(c =>
                        c.Name.StartsWith(prefix, StringComparison.OrdinalIgnoreCase) ||
                        c.Id.StartsWith(prefix, StringComparison.OrdinalIgnoreCase));

                    if (match != null)
                    {
                        _inputBuffer = _inputBuffer.Contains(" ")
                            ? _inputBuffer.Split(' ')[0] + " " + match.Name
                            : "/join " + match.Name;

                        _inputCursorPosition = _inputBuffer.Length;
                        DrawInputArea();
                        RestoreCursorToInput();
                    }
                }
            }
            else if (_inputBuffer.StartsWith("@"))
            {
                // Auto-complete username
                string prefix = _inputBuffer.TrimStart('@');

                if (!string.IsNullOrEmpty(prefix))
                {
                    var users = await _userService.GetActiveUsers();
                    var match = users.FirstOrDefault(u =>
                        u.Username.StartsWith(prefix, StringComparison.OrdinalIgnoreCase) ||
                        (u.DisplayName != null && u.DisplayName.StartsWith(prefix, StringComparison.OrdinalIgnoreCase)));

                    if (match != null)
                    {
                        _inputBuffer = "@" + match.Username + " ";
                        _inputCursorPosition = _inputBuffer.Length;
                        DrawInputArea();
                        RestoreCursorToInput();
                    }
                }
            }
        }

        private async Task ProcessInput()
        {
            if (string.IsNullOrWhiteSpace(_inputBuffer))
                return;

            string input = _inputBuffer.Trim();
            _inputBuffer = string.Empty;
            _inputCursorPosition = 0;

            DrawInputArea();
            RestoreCursorToInput();

            if (input.StartsWith("/"))
            {
                // Handle command
                var result = await _commandHandler.ProcessCommand(input);

                if (!result.Success)
                {
                    ShowNotification(result.Message);
                }
                else if (result.Message == "clear")
                {
                    await RefreshUI();
                }
                else if (input.StartsWith("/help"))
                {
                    // Special handling for help command
                    ShowHelpMessage(result.Message);
                }
                else if (!string.IsNullOrEmpty(result.Message))
                {
                    ShowNotification(result.Message);
                }
            }
            else
            {
                // Regular message
                try
                {
                    await _messageService.SendMessage(input, _channelService.CurrentChannelId);
                }
                catch (Exception ex)
                {
                    ShowNotification($"Error sending message: {ex.Message}");
                }
            }
        }

        private void DrawInputArea()
        {
            try
            {
                int inputAreaTop = _consoleHeight - 2;
                int inputAreaWidth = _consoleWidth - Config.SidebarWidth - 1;

                // Draw input background
                Console.SetCursorPosition(Config.SidebarWidth + 1, inputAreaTop);
                Console.BackgroundColor = Config.Colors["input_bg"];
                Console.ForegroundColor = Config.Colors["input_fg"];

                string channelName = _channelService.CurrentChannel?.Name ?? _channelService.CurrentChannelId;
                string prompt = $"[#{channelName}] ";
                string displayText = prompt + _inputBuffer;

                // Ensure we don't write beyond console width
                if (displayText.Length > inputAreaWidth)
                {
                    // Truncate from the beginning if it gets too long
                    int overflow = displayText.Length - inputAreaWidth;
                    displayText = "..." + displayText.Substring(overflow + 3);
                }
                else
                {
                    // Pad with spaces to clear previous text
                    displayText = displayText.PadRight(inputAreaWidth);
                }

                Console.Write(displayText);
                Console.ResetColor();
            }
            catch (Exception ex)
            {
                LogError($"Error drawing input area: {ex.Message}");
            }
        }

        private void RestoreCursorToInput()
        {
            try
            {
                int inputAreaTop = _consoleHeight - 2;
                string channelName = _channelService.CurrentChannel?.Name ?? _channelService.CurrentChannelId;
                string prompt = $"[#{channelName}] ";

                // Calculate visual cursor position
                int visualCursorPos = prompt.Length + _inputCursorPosition;

                // Handle when input is too long
                int inputAreaWidth = _consoleWidth - Config.SidebarWidth - 1;
                if (prompt.Length + _inputBuffer.Length > inputAreaWidth)
                {
                    // The text is truncated with "..."
                    int overflow = (prompt.Length + _inputBuffer.Length) - inputAreaWidth;
                    if (_inputCursorPosition < overflow + 3)
                    {
                        // Cursor would be in the truncated part
                        visualCursorPos = 3; // Position after "..."
                    }
                    else
                    {
                        visualCursorPos = prompt.Length + _inputCursorPosition - overflow;
                    }
                }

                Console.SetCursorPosition(Config.SidebarWidth + 1 + visualCursorPos, inputAreaTop);
                Console.CursorVisible = true;
            }
            catch (Exception ex)
            {
                LogError($"Error restoring cursor: {ex.Message}");
            }
        }

        /// <summary>
        /// Special method to handle the help command with a better display
        /// </summary>
        private void ShowHelpMessage(string helpText)
        {
            try
            {
                // Set flag to indicate help is showing
                _isShowingHelp = true;

                // Clear the chat area first
                int chatAreaWidth = _consoleWidth - Config.SidebarWidth - 1;
                int chatAreaHeight = _consoleHeight - 2;

                Console.BackgroundColor = ConsoleColor.Black;

                for (int i = 0; i < chatAreaHeight; i++)
                {
                    Console.SetCursorPosition(Config.SidebarWidth + 1, i);
                    Console.Write(new string(' ', chatAreaWidth));
                }

                // Display help message with better formatting
                Console.SetCursorPosition(Config.SidebarWidth + 2, 1);
                Console.ForegroundColor = ConsoleColor.Yellow;
                Console.WriteLine("HELP: AVAILABLE COMMANDS");
                Console.ForegroundColor = ConsoleColor.Gray;

                string[] lines = helpText.Split('\n');
                int currentLine = 3;

                foreach (string line in lines)
                {
                    if (currentLine >= chatAreaHeight)
                        break;

                    Console.SetCursorPosition(Config.SidebarWidth + 2, currentLine);

                    // Highlight categories (lines ending with ":")
                    if (line.Trim().EndsWith(":"))
                    {
                        Console.ForegroundColor = ConsoleColor.Cyan;
                        Console.Write(line);
                    }
                    // Highlight command names (lines with " - ")
                    else if (line.Contains(" - "))
                    {
                        int dashIndex = line.IndexOf(" - ");
                        string commandPart = line.Substring(0, dashIndex).Trim();
                        string descriptionPart = line.Substring(dashIndex);

                        // Command part
                        Console.ForegroundColor = ConsoleColor.Green;
                        Console.Write(commandPart);

                        // Description part
                        Console.ForegroundColor = ConsoleColor.Gray;
                        Console.Write(descriptionPart);
                    }
                    else
                    {
                        Console.ForegroundColor = ConsoleColor.Gray;
                        Console.Write(line);
                    }

                    currentLine++;
                }

                // Add a note about pressing a key to dismiss
                if (currentLine < chatAreaHeight - 2)
                {
                    Console.SetCursorPosition(Config.SidebarWidth + 2, currentLine + 2);
                    Console.ForegroundColor = ConsoleColor.DarkGray;
                    Console.Write("Press any key to continue...");
                }

                // Restore cursor to input area
                Console.ForegroundColor = ConsoleColor.Gray;
                RestoreCursorToInput();
            }
            catch (Exception ex)
            {
                LogError($"Error showing help: {ex.Message}");
                _isShowingHelp = false;
            }
        }

        private void ShowNotification(string message)
        {
            // Display a notification at the bottom of the screen
            try
            {
                int notificationTop = _consoleHeight - 1;

                Console.SetCursorPosition(Config.SidebarWidth + 1, notificationTop);
                Console.BackgroundColor = ConsoleColor.DarkGray;
                Console.ForegroundColor = ConsoleColor.White;

                // Truncate if message is too long
                int maxWidth = _consoleWidth - Config.SidebarWidth - 1;
                if (message.Length > maxWidth)
                {
                    message = message.Substring(0, maxWidth - 3) + "...";
                }
                else
                {
                    message = message.PadRight(maxWidth);
                }

                Console.Write(message);
                Console.ResetColor();

                // Restore cursor to input area
                RestoreCursorToInput();

                // Clear notification after a delay
                Task.Run(async () =>
                {
                    await Task.Delay(5000);

                    // Don't clear if we're in help mode
                    if (!_isShowingHelp)
                    {
                        Console.SetCursorPosition(Config.SidebarWidth + 1, notificationTop);
                        Console.Write(new string(' ', maxWidth));
                        RestoreCursorToInput();
                    }
                });
            }
            catch (Exception ex)
            {
                LogError($"Error showing notification: {ex.Message}");
            }
        }

        private void LogError(string message)
        {
            Console.ForegroundColor = ConsoleColor.Red;
            Console.WriteLine($"[ERROR] {message}");
            Console.ResetColor();
        }
    }
}